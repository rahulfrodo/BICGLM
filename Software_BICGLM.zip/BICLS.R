# Function implenting BICLS method
#########################################################
# @ y = response
# @ X = covariate matrix
# @ R = constraint matrix
# @ b = constrain bound b s.t R\beta>= b
# @ m1= Number of equalities, should be in top rows of R
# @ a0,b0 = paramter for inverse gamma distribution
# @ n.samples= Number of MCMC samples from the posterior
#########################################################
Bayes.con.slm<-function(y,X,R,b,m1,
                        a0=0.01,b0=0.01,
                        n.samples=5000){
  n<-length(y)
  p<-ncol(X)
  m<-length(b)
  R.svd<- svd(R)
  Rinv<- R.svd$v %*%diag(1/R.svd$d)%*%t(R.svd$u)
  Y<-y-X%*%Rinv%*%b
  R12inv=Rinv[,(m1+1):m]
  X1<-X%*%R12inv
  Mat2<-(diag(p)-Rinv%*%R)
  X2<-X%*%Mat2
  
  
  #intial values:
  ols     <- lm(Y~-1+X1+X2)            
  sigma2  <- var(ols$residuals)
  deltainit    <- as.numeric(ols$coef[1:(m-m1)])
  eta<-rnorm(p,0,1)
  
  #Initialize matrix to store the results:
  ef=m-m1
  samples <- matrix(0,n.samples,ef+p+1+p)      
  
  mu1=rep(0,ef)
  Sigma1=100*diag(ef)
  mu2=rep(0,p)
  Sigma2=100*diag(p)
  
  #needed things for delta
  Sigma1inv<-chol2inv(chol(Sigma1))
  cov1<-chol2inv(chol(t(X1)%*%(X1)+Sigma1inv))
  
  #needed things for eta
  Sigma2inv<-chol2inv(chol(Sigma2))
  L<-t(chol(t(X2)%*%(X2)+Sigma2inv))
  Linv<-forwardsolve(L, diag(dim(L)[1]))
  R2<-t(Linv)
  
  #Start the MCMC sampler:
  for(i in 1:n.samples){
    #update delta:     
    library(tmvmixnorm)
    term1<-t(X1)%*%(Y-X2%*%eta)
    mun1<-cov1%*%(Sigma1inv%*%mu1+term1)
    cov1act<-sigma2*cov1
    delta<-rtmvn(n=1, Mean=mun1, cov1act, D=diag(ef), lower=rep(0,ef), upper=rep(Inf,ef),int=rep(1,ef), burn=10)
    
    #update eta:      
    term2<-t(X2)%*%(Y-X1%*%delta)
    mun2<-R2%*%t(R2)%*%(Sigma2inv%*%mu2+term2)
    z<-rnorm(p)
    eta<- sqrt(sigma2)*R2%*%z +mun2
    
    
    #update sigma^2:
    SSE    <- sum((Y-X1%*%delta-X2%*%eta)^2)
    sigma2 <- 1/rgamma(1,n/2+a0,SSE/2+b0)
    
    #calculate beta
    betapost<- Rinv%*%(b) +R12inv%*%(delta)+ Mat2%*%eta
    
    #store results:
    samples[i,]  <- c(delta,eta,sigma2,betapost)
    }
  
  #return a list with the posterior samples:
  return(samples)}
