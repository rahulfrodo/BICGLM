source('BICLS.R')
source('BICGLM.R')

#######################demo BICLS################################
#################################################################
set.seed(1)
#Simulated example
n     <- 30
sigma <- 3
beta  <- c(3,-2,1,1) #beta0=3
library(mvtnorm)
sigma1=matrix(c(1,.5,.25,.5,1,.5,.25,.5,1),nrow=3,byrow = TRUE)
sigma2=solve(sigma1)              
X<-rmvnorm(n,mean=rep(0,3),sigma2)
X<-cbind(rep(1,n),X)
p<-ncol(X)
y <- rnorm(n,X%*%beta,sigma)
R<-matrix(c(0,-1,0,0,0,0,1,0,0,0,0,1),nrow=3,ncol=4,byrow=TRUE)
#beta1<0 beta2>0 beta3 >0     
b<- rep(0,3)
m<-length(b)
m1=0         #number of binding constraints
m0=m-m1
library(restriktor)
lmod<-lm(y~-1+X)
betaols<-as.numeric(lmod$coefficients)
fit.con <- restriktor(lmod, constraints = R,rhs=b,neq=0)
betaICLS<- coef(fit.con)
burn=2000
n.samples=10000
samples<-Bayes.con.slm(y,X,R,b,m1=0,a0=0.01,b0=0.01,n.samples=10000)    #m1=0
betapost<-samples[burn:n.samples,(m0+p+2):(m0+p+1+p)]
betabayes<-colMeans(betapost)
sum((betabayes-beta)^2)
sum((betaols-beta)^2)
sum((betaICLS-beta)^2)

################demo poisson regression#########################
################################################################

set.seed(1)
n     <- 50
p<-3
beta  <- c(1.5,0.25,1,0.5)
X<-matrix(runif(n*p,-.5,.5),nrow=n,ncol=p)
X<-cbind(rep(1,n),X)
y <- rpois(n,exp(X%*%beta))
R<-cbind(rep(0,3),diag(3)) #beta1 >0 beta2>0 beta3>0, beta0 inactive
b<- rep(0,3)
library(restriktor)
glmod<-glm(y~-1+X,family = poisson(link = "log"))
betaglm<-as.numeric(glmod$coefficients)
fit.con <- restriktor(glmod, constraints = R,rhs=b,neq=0)
betares<- coef(fit.con)
B.est<-Bayes.icon.glm(y,X,R,b,delta =rep(0,n),n.samples=5000,family = "poisson") 
betabayes<-colMeans(B.est$betabayes_ex)

#################demo logistic regression#############################
######################################################################

set.seed(1)
n     <- 200
p<-3
beta  <- c(1.5,0.25,1,0.5)
X<-matrix(runif(n*p,-.5,.5),nrow=n,ncol=p)
X<-cbind(rep(1,n),X)
f1<-function(u){(1/(1+exp(-u)))}
y <- rbinom(n,1,f1(X%*%beta))
R<-cbind(rep(0,3),diag(3)) #beta1 >0 beta2>0 beta3>0, beta0 inactive
b<- rep(0,3)
library(restriktor)
glmod<-glm(y~-1+X,family = binomial)
betaglm<-as.numeric(glmod$coefficients)
fit.con <- restriktor(glmod, constraints = R,rhs=b,neq=0)
betares<- coef(fit.con)
B.est<-Bayes.icon.glm(y,X,R,b,delta =rep(0,n),n.samples=5000,family = "binomial") 
betabayes<-colMeans(B.est$betabayes_ex)
sum((betabayes-beta)^2)
sum((betaglm-beta)^2)
sum((betares-beta)^2)

