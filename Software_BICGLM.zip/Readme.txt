# Contains html and Rmarkdown illustration of the applications 
# using the proposed method in the article
# BICGLM_DEMO.html is the .html output
# BICGLM_DEMO.Rmd is the rmakdown file
 




