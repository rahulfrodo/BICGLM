# Contains scripts BICLS.R and BICGLM.R which needs to be sourced
# BICGLM_DEMO.R illustrates a demonstration of using the functions
# Function implenting BICLS method
#########################################################
# @ y = response
# @ X = covariate matrix
# @ R = constraint matrix
# @ b = constrain bound b s.t R\beta>= b
# @ m1= Number of equalities, should be in top rows of R
# @ a0,b0 = paramter for inverse gamma distribution
# @ n.samples= Number of MCMC samples from the posterior
#########################################################
Bayes.con.slm(y,X,R,b,m1,a0=0.01,b0=0.01,n.samples=5000)
##########################################################
# Function implenting BICGLM method with no binding constraints
# Currently implements Poisson and logistic regression
# Case with binding constraints can be reduced to this, see the paper
######################################################################
# @ y = response (count for poisson, binary for logistic regression)
# @ X = covariate matrix
# @ R = constraint matrix
# @ b = constrain bound b s.t R\beta>= b
# @ delta= offset term
# @ n.samples= # of samples from the posterior using rejection sampler
# @ family= GLM family, one of "poisson" or "binomial" currently
######################################################################
Bayes.icon.glm<-function(y,X,R,b,delta,n.samples=5000,family='poisson')




