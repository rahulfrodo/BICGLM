# Function implenting BICGLM method with no binding constraints
# Currently implements Poisson and logistic regression
# Case with binding constraints can be reduced to this, see the paper
######################################################################
# @ y = response (count for poisson, binary for logistic regression)
# @ X = covariate matrix
# @ R = constraint matrix
# @ b = constrain bound b s.t R\beta>= b
# @ delta= offset term
# @ n.samples= # of samples from the posterior using rejection sampler
# @ family= GLM family, one of "poisson" or "binomial" currently
######################################################################
Bayes.icon.glm<-function(y,X,R,b,delta,n.samples=5000,family='poisson'){
  if(family=="poisson"){
  n<-length(y)
  p<-ncol(X)
  m<-length(b)
  #Get Glm Betahat
  #Change family to binomial for logit 
  glmod<-glm(y~-1+X,offset = delta,family = poisson(link = "log"))   #offset = c.time[nzero.indx]
  betaglm<-as.numeric(glmod$coefficients)    
  sdbeta<-as.numeric(summary(glmod)[["coefficients"]][,2])
  
  
  Ibetafunc<-function(beta)
  {
    gamma2<-c()
    for(i in 1:n)
    {temp=crossprod(X[i,],beta)+delta[i]
    gamma2[i]=exp(temp)  #Change to different \psi^'' for binomial
    }
    GamaMat2<-diag(gamma2)
    Ibetahat<-t(X)%*%GamaMat2%*%X
    return(Ibetahat)
  }
  
  Ibetahat<-Ibetafunc(betaglm)
  mu1=rep(0,p)
  Sigma1=100000*diag(p)
  
  Sigma1inv<-chol2inv(chol(Sigma1))
  Sigmapost<-chol2inv(chol(Ibetahat+Sigma1inv))
  mupost<-Sigmapost%*%(Ibetahat%*%betaglm+Sigma1inv%*%mu1)
  
  N=n.samples
  library(MASS)
  #scaled log likelihood function for poisson
  log.like=function(beta){
    mu=as.vector((X%*%beta)+delta)
    return(sum(y*mu - exp(mu))/n)
  }
  
  log.density.exact=function(beta){
    as.vector(-0.5*t(beta-betaglm)%*%FI.exact%*%(beta-betaglm)/n)
  }
  
  #Obtain bound for exact RS using stochastic search:
  h=function(beta){
    log.like(beta) - log.density.exact(beta)
  }
  #using stochastic optimization: try larger N.sim for more accuracy
  FI.exact=Ibetafunc(betaglm)
  Sigma.exact=chol2inv(chol(FI.exact))
  N.sim=1.0e3
  library(tmvmixnorm)
  M.exact=max(apply(rtmvn(n=N.sim,Mean=betaglm,10*Sigma.exact,D=R, lower=b, upper=rep(Inf,m),int=rep(1,p), burn=10),1,h))
  #Exact RS:
  RS.exact=function(it){
    max.try=100
    try=1
    while(try<max.try){
      #generate beta 
      library(tmvmixnorm)
      beta= rtmvn(n=1, Mean=mupost, Sigmapost, D=R, lower=b, upper=rep(Inf,m),int=rep(1,p), burn=10)
      #generate chisq2
      v=rchisq(1,df=2)
      if(v > 2*(log.density.exact(beta)-log.like(beta)+M.exact)){return(c(beta,try))}
      try=try+1
    }
    return(c(rep(NA,p),try))
  }
  
  beta.sam.exact=t(sapply(1:N,RS.exact))
  resullt<-list("betabayes_ex"=beta.sam.exact[,-(p+1)])
  return(resullt)
  }
  
  if(family=="binomial")
  {
    n<-length(y)
    p<-ncol(X)
    m<-length(b)
    #Get Glm Betahat
    #Change family to binomial for logit 
    glmod<-glm(y~-1+X,offset = delta,family = binomial(link = "logit"))   #offset = c.time[nzero.indx]
    betaglm<-as.numeric(glmod$coefficients)    
    sdbeta<-as.numeric(summary(glmod)[["coefficients"]][,2])
    
    
    Ibetafunc<-function(beta)
    {
      gamma2<-c()
      for(i in 1:n)
      {temp=crossprod(X[i,],beta)+delta[i]
      gamma2[i]=(exp(temp)/((1+exp(temp))^2))  #Change to different \psi^'' for binomial
      }
      GamaMat2<-diag(gamma2)
      Ibetahat<-t(X)%*%GamaMat2%*%X
      return(Ibetahat)
    }
    
    Ibetahat<-Ibetafunc(betaglm)
    mu1=rep(0,p)
    Sigma1=100000*diag(p)
    
    Sigma1inv<-chol2inv(chol(Sigma1))
    Sigmapost<-chol2inv(chol(Ibetahat+Sigma1inv))
    mupost<-Sigmapost%*%(Ibetahat%*%betaglm+Sigma1inv%*%mu1)
    
    N=n.samples
    library(MASS)
    #scaled log likelihood function for poisson
    log.like=function(beta){
      mu=as.vector((X%*%beta)+delta)
      return(sum(y*mu - log(1+exp(mu)))/n)
    }
    
    log.density.exact=function(beta){
      as.vector(-0.5*t(beta-betaglm)%*%FI.exact%*%(beta-betaglm)/n)
    }
    
    #Obtain bound for exact RS using stochastic search:
    h=function(beta){
      log.like(beta) - log.density.exact(beta)
    }
    #using stochastic optimization: try larger N.sim for more accuracy
    FI.exact=Ibetafunc(betaglm)
    Sigma.exact=chol2inv(chol(FI.exact))
    N.sim=1.0e3
    library(tmvmixnorm)
    M.exact=max(apply(rtmvn(n=N.sim,Mean=betaglm,10*Sigma.exact,D=R, lower=b, upper=rep(Inf,m),int=rep(1,p), burn=10),1,h))
    #Exact RS:
    RS.exact=function(it){
      max.try=100
      try=1
      while(try<max.try){
        #generate beta 
        library(tmvmixnorm)
        beta= rtmvn(n=1, Mean=mupost, Sigmapost, D=R, lower=b, upper=rep(Inf,m),int=rep(1,p), burn=10)
        #generate chisq2
        v=rchisq(1,df=2)
        if(v > 2*(log.density.exact(beta)-log.like(beta)+M.exact)){return(c(beta,try))}
        try=try+1
      }
      return(c(rep(NA,p),try))
    }
    
    beta.sam.exact=t(sapply(1:N,RS.exact))
    resullt<-list("betabayes_ex"=beta.sam.exact[,-(p+1)])
    return(resullt)
    }
}


#######demo poisson regression################
set.seed(1)
n     <- 50
p<-3
beta  <- c(1.5,0.25,1,0.5)
X<-matrix(runif(n*p,-.5,.5),nrow=n,ncol=p)
X<-cbind(rep(1,n),X)
y <- rpois(n,exp(X%*%beta))
R<-cbind(rep(0,3),diag(3)) #beta1 >0 beta2>0 beta3>0, beta0 inactive
b<- rep(0,3)
library(restriktor)
glmod<-glm(y~-1+X,family = poisson(link = "log"))
betaglm<-as.numeric(glmod$coefficients)
fit.con <- restriktor(glmod, constraints = R,rhs=b,neq=0)
betares<- coef(fit.con)
B.est<-Bayes.icon.glm(y,X,R,b,delta =rep(0,n),n.samples=5000,family = "poisson") 
betabayes<-colMeans(B.est$betabayes_ex)
#######demo logistic regression################
set.seed(1)
n     <- 200
p<-3
beta  <- c(1.5,0.25,1,0.5)
X<-matrix(runif(n*p,-.5,.5),nrow=n,ncol=p)
X<-cbind(rep(1,n),X)
f1<-function(u){(1/(1+exp(-u)))}
y <- rbinom(n,1,f1(X%*%beta))
R<-cbind(rep(0,3),diag(3)) #beta1 >0 beta2>0 beta3>0, beta0 inactive
b<- rep(0,3)
library(restriktor)
glmod<-glm(y~-1+X,family = binomial)
betaglm<-as.numeric(glmod$coefficients)
fit.con <- restriktor(glmod, constraints = R,rhs=b,neq=0)
betares<- coef(fit.con)
B.est<-Bayes.icon.glm(y,X,R,b,delta =rep(0,n),n.samples=5000,family = "binomial") 
betabayes<-colMeans(B.est$betabayes_ex)
sum((betabayes-beta)^2)
sum((betaglm-beta)^2)
sum((betares-beta)^2)
